# Program to print odd numbers up to n

n = int(input("Enter n: "))

i = 1

while i <= n:
    print(i, end=" ")
    i += 2