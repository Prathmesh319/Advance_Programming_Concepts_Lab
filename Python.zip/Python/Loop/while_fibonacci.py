# Program to print Fibonacci series up to n terms

n = int(input("Enter number of terms: "))

a = 0
b = 1
i = 1

while i <= n:
    print(a, end=" ")

    c = a + b
    a = b
    b = c

    i += 1