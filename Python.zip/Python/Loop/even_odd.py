# Program to check whether a number is even or odd

n = int(input("Enter a number: "))

if n % 2 == 0:
    print("The number is even.")
else:
    print("The number is odd.")